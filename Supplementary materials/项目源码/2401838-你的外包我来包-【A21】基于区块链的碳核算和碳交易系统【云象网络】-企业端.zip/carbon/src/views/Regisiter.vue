<script setup>
import {reactive, ref} from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';
import { ElMessage } from "element-plus";
import {useStore} from "vuex";

const router = useRouter();

const loginData =  ref({
  username: '',
  password: ''
})
const companyForm = reactive({
  CompanyID: '',
  Password: '',
  CarbonCoin: 0,
  Avatar: '',
  CompanyName: '',
  CarbonCredit: 0,
  Examine: 0,
  PhoneNumber: '',
  Email: '',
  Type: 0
});
const resetCompanyForm = () => {
  companyForm.CompanyID = '';
  companyForm.Password = '';
  companyForm.CarbonCoin = 0;
  companyForm.Avatar = '';
  companyForm.CompanyName = '';
  companyForm.CarbonCredit = 0;
  companyForm.Examine = 0;
  companyForm.PhoneNumber = '';
  companyForm.Email = '';
  companyForm.Type = 0;
};
// const onSubmitLogin = async () => {
//   try {
//     const response = await axios.post('http://47.97.176.174:8087/chainmaker?cmb=CompanyLogin', {
//       CompanyID: loginData.username,
//       Password: loginData.password
//     });
//     if (response.data.msg === "请前往注册") {
//       ElMessage({
//         message: '请前往注册',
//         type: 'warning',
//       })
//     } else {
//       ElMessage({
//         message: '登录成功',
//         type: 'success',
//       })
//       router.push('/Home');
//     }
//     console.log(response)
//   } catch (error) {
//     ElMessage.error('登录失败')
//     console.error(error);
//   }
// };
const store = useStore()
const onSubmit =() => {
    store.dispatch('login',{
      companyid: loginData.value.username,
      password: loginData.value.password
    }).then(() => {
      // router.push({
      //   path: '/DashBoard'
      // })
    }).catch((error) => {
      console.error('登录失败:', error);
      ElMessage.error('登录失败，请检查用户名和密码');
    });
}
const registerCompany = async () => {
  try {
    const response = await axios.post('http://47.97.176.174:8087/chainmaker?cmb=CreateCompany', {
      CompanyID: companyForm.CompanyID,
      Password : companyForm.Password,
      CarbonCoin : 0,
      Avatar : "null",
      CompanyName : companyForm.CompanyName,
      CarbonCredit : 0,
      Examine : 0,
      PhoneNumber : companyForm.PhoneNumber,
      Email : companyForm.Email,
      Type : 0
    });
    resetCompanyForm();
    ElMessage({
      message: '公司注册成功，请等待审核通过~',
      type: 'success',
    })
    document.querySelector(".container").classList.remove("sign-up-mode");
    console.log(response)
  } catch (error) {
    ElMessage.error('注册失败')
    console.error(error);
  }
};

// document.addEventListener('DOMContentLoaded', (event) => {
//   const sign_in_btn = document.querySelector("#sign-in-btn");
//   const sign_up_btn = document.querySelector("#sign-up-btn");
//   const container = document.querySelector(".container");
//
//   sign_up_btn.addEventListener("click", () => {
//     container.classList.add("sign-up-mode");
//   });
//   sign_in_btn.addEventListener("click", () => {
//     container.classList.remove("sign-up-mode");
//   });
// });
const goreg = ()=>{
  const container =document.querySelector(".container")
  container.classList.add("sign-up-mode");
}
const gologin = () =>{
  resetCompanyForm();
  const container =document.querySelector(".container")
  container.classList.remove("sign-up-mode");
}
</script>

<template>
  <div class="container">
    <div class="forms-container">
      <div class="signin-signup">
        <form @submit.prevent="onSubmit" class="sign-in-form">
          <h2 class="title">登录</h2>
          <div class="input-field">
<!--            <i class="fas fa-user"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><User /></el-icon>
            <input type="text" placeholder="请输入公司ID" v-model="loginData.username" />
          </div>
          <div class="input-field">
<!--            <i class="fas fa-key"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><Lock /></el-icon>
            <input type="password" placeholder="请输入密码" v-model="loginData.password" />
          </div>
          <input type="submit" value="立即登录"  class="btn solid" />
          <p class="social-text">其他方式登录</p>
          <div class="social-media">
            <a href="https://im.qq.com/index/" target="_blank" class="social-icon">
              <i class="fab fa-qq"></i>
            </a>
            <a href="https://weixin.qq.com" target="_blank" class="social-icon">
              <i class="fab fa-weixin"></i>
            </a>
            <a href="https://weibo.com/newlogin?tabtype=weibo&gid=102803&openLoginLayer=0&url=https%3A%2F%2Fweibo.com%2F" target="_blank" class="social-icon">
              <i class="fab fa-weibo"></i>
            </a>
            <a href="https://www.alipay.com" target="_blank" class="social-icon">
              <i class="fab fa-alipay"></i>
            </a>
          </div>
        </form>
        <form @submit.prevent="registerCompany" class="sign-up-form">
          <h2 class="title">注册</h2>
          <div class="input-field">
<!--            <i class="fas fa-user"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><Postcard /></el-icon>
            <input type="text" placeholder="请输入公司名称" v-model="companyForm.CompanyName" />
          </div>
          <div class="input-field">
<!--            <i class="fas fa-user"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><User /></el-icon>
            <input type="text" placeholder="请输入公司ID" v-model="companyForm.CompanyID" />
          </div>
          <div class="input-field">
<!--            <i class="fas fa-lock"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><Lock /></el-icon>
            <input type="password" placeholder="请输入密码" v-model="companyForm.Password" />
          </div>
          <div class="input-field">
<!--            <i class="fas fa-phone"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><Iphone /></el-icon>
            <input type="password" placeholder="请输入电话" v-model="companyForm.PhoneNumber" />
          </div>
          <div class="input-field">
<!--            <i class="fas fa-envelope"></i>-->
            <el-icon size="24" style="margin-left: 16px;margin-top: 15px"><Message /></el-icon>
            <input type="password" placeholder="请输入邮箱" v-model="companyForm.Email" />
          </div>
          <input type="submit" class="btn" value="立即注册" />
          <p class="social-text">其他方式登录</p>
          <div class="social-media">
            <a href="https://im.qq.com/index/" target="_blank" class="social-icon">
              <i class="fab fa-qq"></i>
            </a>
            <a href="https://weixin.qq.com" target="_blank" class="social-icon">
              <i class="fab fa-weixin"></i>
            </a>
            <a href="https://weibo.com/newlogin?tabtype=weibo&gid=102803&openLoginLayer=0&url=https%3A%2F%2Fweibo.com%2F" target="_blank" class="social-icon">
              <i class="fab fa-weibo"></i>
            </a>
            <a href="https://www.alipay.com" target="_blank" class="social-icon">
              <i class="fab fa-alipay"></i>
            </a>
          </div>
        </form>
      </div>
    </div>

    <div class="panels-container">
      <div class="panel left-panel">
        <div class="content">
          <h3>加入我们</h3>
          <p>
            加入我们，成为本站的一份子。
          </p>
          <button class="btn transparent" id="sign-up-btn" @click="goreg">
            去注册
          </button>
        </div>
        <img src="@/assets/login/login.svg" class="image" alt="login" />
      </div>
      <div class="panel right-panel">
        <div class="content">
          <h3>已有帐号？</h3>
          <p>
            立即登录已有帐号，享受独家权益。
          </p>
          <button class="btn transparent" id="sign-in-btn" @click="gologin">
            去登录
          </button>
        </div>
        <img src="@/assets/login/register.svg" class="image" alt="register" />
      </div>
    </div>
  </div>
</template>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap");

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body,
input {
  font-family: "Poppins", sans-serif;
}

.container {
  position: relative;
  width: 100%;
  background-color: #fff;
  min-height: 100vh;
  overflow: hidden;
}

.forms-container {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
}

.signin-signup {
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  left: 75%;
  width: 50%;
  transition: 1s 0.7s ease-in-out;
  display: grid;
  grid-template-columns: 1fr;
  z-index: 5;
}

form {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  padding: 0 5rem;
  transition: all 0.2s 0.7s;
  overflow: hidden;
  grid-column: 1 / 2;
  grid-row: 1 / 2;
}

form.sign-up-form {
  opacity: 0;
  z-index: 1;
}

form.sign-in-form {
  z-index: 2;
}

.title {
  font-size: 2.2rem;
  color: #444;
  margin-bottom: 10px;
}

.input-field {
  max-width: 380px;
  width: 100%;
  background-color: #f0f0f0;
  margin: 10px 0;
  height: 55px;
  border-radius: 55px;
  display: grid;
  grid-template-columns: 15% 85%;
  padding: 0 0.4rem;
  position: relative;
}

.input-field i {
  text-align: center;
  line-height: 55px;
  color: #acacac;
  transition: 0.5s;
  font-size: 1.1rem;
}

.input-field input {
  background: none;
  outline: none;
  border: none;
  line-height: 1;
  font-weight: 600;
  font-size: 1.1rem;
  color: #333;
}

.input-field input::placeholder {
  color: #aaa;
  font-weight: 500;
}

.social-text {
  padding: 0.7rem 0;
  font-size: 1rem;
}

.social-media {
  display: flex;
  justify-content: center;
}

.social-icon {
  height: 46px;
  width: 46px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 0.45rem;
  color: #333;
  border-radius: 50%;
  border: 1px solid #333;
  text-decoration: none;
  font-size: 1.1rem;
  transition: 0.3s;
}

.social-icon:hover {
  color: #4481eb;
  border-color: #4481eb;
}

.btn {
  width: 150px;
  background-color: #5995fd;
  border: none;
  outline: none;
  height: 49px;
  border-radius: 49px;
  color: #fff;
  text-transform: uppercase;
  font-weight: 600;
  margin: 10px 0;
  cursor: pointer;
  transition: 0.5s;
}

.btn:hover {
  background-color: #4d84e2;
}

.panels-container {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
}

.container:before {
  content: "";
  position: absolute;
  height: 2000px;
  width: 2000px;
  top: -10%;
  right: 48%;
  transform: translateY(-50%);
  background-image: linear-gradient(-45deg, #4481eb 0%, #04befe 100%);
  transition: 1.8s ease-in-out;
  border-radius: 50%;
  z-index: 6;
}

.image {
  width: 100%;
  transition: transform 1.1s ease-in-out;
  transition-delay: 0.4s;
}

.panel {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: space-around;
  text-align: center;
  z-index: 6;
}

.left-panel {
  pointer-events: all;
  padding: 3rem 17% 2rem 12%;
}

.right-panel {
  pointer-events: none;
  padding: 3rem 12% 2rem 17%;
}

.panel .content {
  color: #fff;
  transition: transform 0.9s ease-in-out;
  transition-delay: 0.6s;
}

.panel h3 {
  font-weight: 600;
  line-height: 1;
  font-size: 1.5rem;
}

.panel p {
  font-size: 0.95rem;
  padding: 0.7rem 0;
}

.btn.transparent {
  margin: 0;
  background: none;
  border: 2px solid #fff;
  width: 130px;
  height: 41px;
  font-weight: 600;
  font-size: 0.8rem;
}

.right-panel .image,
.right-panel .content {
  transform: translateX(800px);
}

/* ANIMATION */

.container.sign-up-mode:before {
  transform: translate(100%, -50%);
  right: 52%;
}

.container.sign-up-mode .left-panel .image,
.container.sign-up-mode .left-panel .content {
  transform: translateX(-800px);
}

.container.sign-up-mode .signin-signup {
  left: 25%;
}

.container.sign-up-mode form.sign-up-form {
  opacity: 1;
  z-index: 2;
}

.container.sign-up-mode form.sign-in-form {
  opacity: 0;
  z-index: 1;
}

.container.sign-up-mode .right-panel .image,
.container.sign-up-mode .right-panel .content {
  transform: translateX(0%);
}

.container.sign-up-mode .left-panel {
  pointer-events: none;
}

.container.sign-up-mode .right-panel {
  pointer-events: all;
}

@media (max-width: 870px) {
  .container {
    min-height: 800px;
    height: 100vh;
  }

  .signin-signup {
    width: 100%;
    top: 95%;
    transform: translate(-50%, -100%);
    transition: 1s 0.8s ease-in-out;
  }

  .signin-signup,
  .container.sign-up-mode .signin-signup {
    left: 50%;
  }

  .panels-container {
    grid-template-columns: 1fr;
    grid-template-rows: 1fr 2fr 1fr;
  }

  .panel {
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    padding: 2.5rem 8%;
    grid-column: 1 / 2;
  }

  .right-panel {
    grid-row: 3 / 4;
  }

  .left-panel {
    grid-row: 1 / 2;
  }

  .image {
    width: 200px;
    transition: transform 0.9s ease-in-out;
    transition-delay: 0.6s;
  }

  .panel .content {
    padding-right: 15%;
    transition: transform 0.9s ease-in-out;
    transition-delay: 0.8s;
  }

  .panel h3 {
    font-size: 1.2rem;
  }

  .panel p {
    font-size: 0.7rem;
    padding: 0.5rem 0;
  }

  .btn.transparent {
    width: 110px;
    height: 35px;
    font-size: 0.7rem;
  }

  .container:before {
    width: 1500px;
    height: 1500px;
    transform: translateX(-50%);
    left: 30%;
    bottom: 68%;
    right: initial;
    top: initial;
    transition: 2s ease-in-out;
  }

  .container.sign-up-mode:before {
    transform: translate(-50%, 100%);
    bottom: 32%;
    right: initial;
  }

  .container.sign-up-mode .left-panel .image,
  .container.sign-up-mode .left-panel .content {
    transform: translateY(-300px);
  }

  .container.sign-up-mode .right-panel .image,
  .container.sign-up-mode .right-panel .content {
    transform: translateY(0px);
  }

  .right-panel .image,
  .right-panel .content {
    transform: translateY(300px);
  }

  .container.sign-up-mode .signin-signup {
    top: 5%;
    transform: translate(-50%, 0);
  }
}

@media (max-width: 570px) {
  form {
    padding: 0 1.5rem;
  }

  .image {
    display: none;
  }

  .panel .content {
    padding: 0.5rem 1rem;
  }

  .container {
    padding: 1.5rem;
  }

  .container:before {
    bottom: 72%;
    left: 50%;
  }

  .container.sign-up-mode:before {
    bottom: 28%;
    left: 50%;
  }
}
</style>
