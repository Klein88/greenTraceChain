<template>
  <div style="background-color: #FFFFFF;height: 720px;margin-top: 20px; margin-left: 20px; margin-right: 20px;margin-bottom: 20px">
    <span style="font-size: 50px;margin-top: 300px;margin-left: 450px;display: inline-block;">上传成功！</span>
  </div>
</template>
<script>
</script>
