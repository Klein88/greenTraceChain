package client

import (
	sdk "chainmaker.org/chainmaker/sdk-go/v3"
)

var ChainMakerClient *sdk.ChainClient
