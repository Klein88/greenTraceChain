package Utils

var FileURI = "/root/qiuwenhao/CompanyTransactionDatas" //   "/root/qiuwenhao/CompanyTransactionDatas" "/Users/qiuwenhao/Desktop/chainmaker/Data"
