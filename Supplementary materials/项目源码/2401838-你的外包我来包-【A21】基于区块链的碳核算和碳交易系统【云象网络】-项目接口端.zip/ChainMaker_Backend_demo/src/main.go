package main

import (
	"ChainMaker_Backend_demo/router"
	"ChainMaker_Backend_demo/src/client"
	"ChainMaker_Backend_demo/src/dao"
	sdk "chainmaker.org/chainmaker/sdk-go/v3"
	"fmt"
	"os"
)

// @title			Swagger Example API
// @version		1.0
// @license.name	Apache 2.0
// @license.url	http://www.apache.org/licenses/LICENSE-2.0.html
func main() {

	currentDir, err := os.Getwd()
	if err != nil {
		// 如果发生错误，打印错误信息
		fmt.Println("Error getting current directory:", err)
		return
	}
	fmt.Printf("Dir :  ", currentDir)

	dao.InitMySql()

	Indexclient, err := sdk.NewChainClient(
		sdk.WithConfPath("../config/sdk_config.yml"),
	)
	client.ChainMakerClient = Indexclient
	if err != nil {
		fmt.Printf(err.Error())
		return
	}

	router.HttpServe()

}
